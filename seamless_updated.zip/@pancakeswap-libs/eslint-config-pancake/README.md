# eslint-config-pancake

Pancake Eslint config with:

- Airbnb config
- Typescript
- Prettier

## Usage

```
npx install-peerdeps --dev @pancakeswap-libs/eslint-config-pancake
```

Add `"extends": "@pancakeswap-libs/eslint-config-pancake"` to your eslint config file.
